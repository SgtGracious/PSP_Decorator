﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class SalaryExpDecorator : Decorator
    {
        public SalaryExpDecorator(IComponent comp) : base(comp) { }

        public override double RecieveSalary()
        {
            return RecieveExpSalary(10, 4);
        }

        public double RecieveExpSalary(int years, double percent)
        {
            double temp = 1.0;
            for (int i = 0; i < years; i++)
            {
                temp = temp * ((percent + 100) / 100);
            }
            return Math.Round(base.RecieveSalary() * temp, 2);
        }
    }
}
