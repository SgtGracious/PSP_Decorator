﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class SalaryEduDecorator : Decorator, ISalary
    {
        public SalaryEduDecorator (IComponent comp) : base(comp) { }

        public override double RecieveSalary()
        {
            var temp = GetPerson(this);
            if (temp is Postgraduate)
            {
                return base.RecieveSalary() * 1.4;
            }
            if (temp is Student)
            {
                return base.RecieveSalary() * 1.1;
            }
            return base.RecieveSalary();
        }
    }
}
