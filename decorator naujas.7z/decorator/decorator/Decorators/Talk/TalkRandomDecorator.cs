﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class TalkRandomDecorator : Decorator, ITalk
    {
        public TalkRandomDecorator(IComponent comp) : base(comp) { }
        
        public void Talk(int option)
        {
            if (option % 3 == 0)
            {
                Console.WriteLine("Man skauda galvą");
            }
            if (option % 3 == 1)
            {
                Console.WriteLine("Man reikia pinigų");
            }
            if (option % 3 == 2)
            {
                Console.WriteLine("Aš vėluosiu");
            }
        }
    }
}
