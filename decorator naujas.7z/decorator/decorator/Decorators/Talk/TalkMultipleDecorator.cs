﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class TalkMultipleDecorator : Decorator, ITalk
    {
        public TalkMultipleDecorator(IComponent comp) : base(comp) { }

        public void Talk(int option)
        {
            for (int j = 0; j < option; j++)
            {
                base.Scream();
            }
        }
    }
}
