using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class Program   
    {
        static void Main(string[] args)
        {
            var individual = new TalkRandomDecorator(new TalkMultipleDecorator(new SalaryExpDecorator(new SalaryEduDecorator(new Postgraduate("asd", 1000, 1)))));

            var role = Decorator.GetRole<SalaryEduDecorator>(individual);
            var role2 = Decorator.GetRole<SalaryExpDecorator>(individual);
            var role3 = Decorator.GetRole<TalkMultipleDecorator>(individual);
            var role4 = Decorator.GetRole<TalkRandomDecorator>(individual);


            if (role != null)
            {
                Console.WriteLine($"{Decorator.GetPerson(role).GetType().Name} with {role.GetType().Name} will recieve {role.RecieveSalary()}");
            }

            if (role2 != null)
            {
                Console.WriteLine($"{Decorator.GetPerson(role2).GetType().Name} with {role2.GetType().Name} will recieve {role2.RecieveExpSalary(20, 4)}");
            }

            if (role3 != null)
            {
                role3.Talk(2);
            }

            if (role4 != null)
            {
                role4.Talk(2);
            }
            Dictionary<string, int> a = new Dictionary<string, int>();
            a.Add("Pirmas", 1);
            a.Add("Antras", 2);
            string name = "Antras";
            Console.WriteLine(a[name]);

            Console.ReadKey();
        }
    }
}
