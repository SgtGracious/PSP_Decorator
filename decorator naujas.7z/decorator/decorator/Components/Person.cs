﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class Person : IComponent
    {
        private string _name;
        private double _salary;
        private double _fte;

        public Person(string name, double salary, double fte)
        {
            _name = name;
            _salary = salary;
            _fte = fte;
        }

        public virtual void Scream()
        {
            Console.WriteLine("Person yells");
        }

        public double RecieveSalary()
        {
            return _salary * _fte;
        }
    }
}
