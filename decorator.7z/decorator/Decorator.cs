﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    abstract class Decorator : IComponent
    {
        private IComponent _comp;

        public Decorator(IComponent component)
        {
            _comp = component;
        }

        public void SetComponent(IComponent component)
        {
            _comp = component;
        }

        public static T GetRole<T>(IComponent comp) where T : Decorator
        {
            if (comp is T decorator)
            {
                return decorator;
            }
            else if(comp is Decorator compDecorator)
            {
                return GetRole<T>(compDecorator._comp);
            }
            else return null;
        }

        public static Person GetPerson(IComponent comp)
        {
            if (comp is Decorator decor)
            {
                return GetPerson(decor._comp);
            }
            if (comp is Postgraduate pg)
            {
                return pg;
            }
            else if (comp is Student stud)
            {
                return stud;
            }
            else if (comp is Person pers)
            {
                return pers;
            }
            return null;
        }

        public virtual void Scream()
        {
            if (_comp != null)
            {
                _comp.Scream();
                Console.WriteLine("Decorator.Scream");
            }
        }

        public virtual double RecieveSalary()
        {
            return GetPerson(_comp).RecieveSalary();
        }
    }
}
