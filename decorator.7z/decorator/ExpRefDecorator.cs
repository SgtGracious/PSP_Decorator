﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class ExpRefDecorator : Decorator
    {
        public ExpRefDecorator(IComponent comp) : base(comp) { }

        public override void Scream()
        {
            Console.WriteLine("ExpRefDecorator.scream");
        }

        public double RecieveSalary(int years, double percent)
        {
            double temp = 1.0;
            for (int i = 0; i < years; i++)
            {
                temp = temp * ((percent + 100) / 100);
            }
            return Math.Round(GetPerson(this).RecieveSalary() * temp, 2);
        }
    }
}
