﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class UnempDecorator : Decorator
    {
        public UnempDecorator(IComponent comp) : base(comp) { }

        public override void Scream()
        {
            Console.WriteLine("NullDecorator.Scream");
        }

        public override double RecieveSalary()
        {
            var temp = GetPerson(this);
            if (!(temp is Student))
            {
                return 555.00;
            }
            return base.RecieveSalary();
        }


    }
}
