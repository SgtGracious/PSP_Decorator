﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class EduRefDecorator : Decorator
    {
        public EduRefDecorator (IComponent comp) : base(comp) { }

        public override void Scream()
        {
            Console.WriteLine("EduRefDecorator.Scream");
        }

        public override double RecieveSalary()
        {
            var temp = GetPerson(this);
            if (temp is Postgraduate)
            {
                return temp.RecieveSalary() * 1.4;
            }
            if (temp is Student)
            {
                return temp.RecieveSalary() * 1.1;
            }
            return temp.RecieveSalary();
        }
    }
}
