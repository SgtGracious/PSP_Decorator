using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class Program   
    {
        static void Main(string[] args)
        {
            var individual = new UnempDecorator(new ExpRefDecorator(new EduRefDecorator(new Postgraduate("asd", 1000, 1))));
            var role = Decorator.GetRole<EduRefDecorator>(individual);
            var role2 = Decorator.GetRole<ExpRefDecorator>(individual);
            var role3 = Decorator.GetRole<UnempDecorator>(individual);
            if (role != null)
            {
                Console.WriteLine($"{Decorator.GetPerson(role).GetType().Name} with {role.GetType().Name} will recieve {role.RecieveSalary()}");
                role.Scream();
            }

            if (role2 != null)
            {
                Console.WriteLine($"{Decorator.GetPerson(role2).GetType().Name} with {role2.GetType().Name} will recieve {role2.RecieveSalary(20, 4)}");
                role2.Scream();
            }

            if (role3 != null)
            {
                Console.WriteLine($"{Decorator.GetPerson(role3).GetType().Name} with {role3.GetType().Name} will recieve {role3.RecieveSalary()}");
                role3.Scream();
            }

            Console.ReadKey();
        }
    }
}
