﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class Person : IComponent
    {
        private string _name;
        private double _salary;
        private double _fte;

        public Person(string name, double salary, double fte)
        {
            _name = name;
            _salary = salary;
            _fte = fte;
        }

        public void Scream()
        {
            Console.WriteLine("Yell");
        }

        public double RecieveSalary()
        {
            double result = _salary * _fte;
            return result;
        }
    }
}
