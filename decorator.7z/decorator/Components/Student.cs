﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator
{
    class Student : Person
    {
        public Student(string name, double salary, double fte) : base(name, salary, fte) { }
    }
}
