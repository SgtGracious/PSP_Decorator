﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extensionObjects
{
    class Postgraduate : Student
    {
        public Postgraduate(string name, double salary, double fte) : base(name, salary, fte) { }

        public override void Scream()
        {
            Console.WriteLine("Postgrad rips hair off");
        }
    }
}
