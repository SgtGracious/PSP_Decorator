﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extensionObjects
{
    class Person : IComponent
    {
        private Dictionary<string, IExtension> _extensions = new Dictionary<string, IExtension>();
        private string _name;
        private double _salary;
        private double _fte;

        public Person(string name, double salary, double fte)
        {
            _name = name;
            _salary = salary;
            _fte = fte;
        }

        public void AddExtension(string name, IExtension extension)
        {
            if (_extensions.ContainsValue(extension))
            {
                Console.WriteLine("This object is already extended by that type");
                return;
            }
            else
            {
                _extensions.Add(name, extension);
            }
            
        }

        public IExtension GetExtension(string name)
        {
            return _extensions[name];
        }

        public void RemoveExtension(string name)
        {
            _extensions.Remove(name);
        }

        public virtual void Scream()
        {
            Console.WriteLine("Yell");
        }

        public double RecieveSalary()
        {
            return _salary * _fte;
        }
    }
}
