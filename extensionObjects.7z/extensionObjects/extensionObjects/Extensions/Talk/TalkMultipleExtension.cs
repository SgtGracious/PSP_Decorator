﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extensionObjects
{
    class TalkMultipleExtension : ITalk
    {
        private IComponent _comp;

        public TalkMultipleExtension(IComponent comp)
        {
            _comp = comp;
        }

        public void Talk(int option)
        {
            for (int j = 0; j < option; j++)
            {
                _comp.Scream();
            }
        }
    }
}
