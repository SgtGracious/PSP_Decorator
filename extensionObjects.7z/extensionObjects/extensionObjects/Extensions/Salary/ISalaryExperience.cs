﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extensionObjects
{
    interface ISalaryExperience : IExtension
    {
        double RecieveSalary(int years, double percent);
    }
}
