﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extensionObjects
{
    class SalaryEduExtension : ISalaryEducation
    {
        private Student _comp;

        public SalaryEduExtension(Student comp)
        {
            _comp = comp;
        }

        public double RecieveSalary()
        {
            if (_comp is Postgraduate)
            {
                return _comp.RecieveSalary() * 1.4;
            }
            if (_comp is Student)
            {
                return _comp.RecieveSalary() * 1.1;
            }
            return _comp.RecieveSalary();
        }
    }
}
