using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extensionObjects
{
    class Program
    {
        static void Main(string[] args)
        {
            var individual = new Student("asd", 1000, 1);
            
            SalaryEduExtension ext = new SalaryEduExtension(individual);  
            SalaryExpExtension ext2 = new SalaryExpExtension(individual);
            TalkMultipleExtension ext3 = new TalkMultipleExtension(individual);
            TalkRandomExtension ext4 = new TalkRandomExtension(individual);

            individual.AddExtension("SalaryEduExtension", ext);
            individual.AddExtension("SalaryExpExtension", ext2);
            individual.AddExtension("TalkMultipleExtension", ext3);
            individual.AddExtension("TalkRandomExtension", ext4);

            var role = (SalaryEduExtension)individual.GetExtension("SalaryEduExtension");
            var role2 = (SalaryExpExtension)individual.GetExtension("SalaryExpExtension");
            var role3 = (TalkMultipleExtension)individual.GetExtension("TalkMultipleExtension");
            var role4 = (TalkRandomExtension)individual.GetExtension("TalkRandomExtension");

            Console.WriteLine($"Base {individual.RecieveSalary()}");

            if (role != null)
            {
                Console.WriteLine($"SalaryEduExtension would recieve {role.RecieveSalary()}");
            }
            if (role2 != null)
            {
                Console.WriteLine($"SalaryExpExtension would recieve {role2.RecieveSalary(10, 4)}");
            }
            if (role3 != null)
            {
                role3.Talk(2);
            }
            if (role4 != null)
            {
                role4.Talk(2);
            }


            Console.ReadKey();
        }
    }
}
